<!doctype html>
<html lang="fr">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Optiday</title>
    </head>

<body>

<h1 style="text-align: :center;"> WORK IN PROGRESS !! </h1>
<p style="text-align: :center;"> Cette section du site est en maintenance, revenez plus tard ! </p>

</body>

</html>