<html lang="fr">
  <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Emploi du temps</title>
  </head>

  <body>

  <?php include('header2.php') ?>

  <div class="boutonsGroup"> <!--debut boutons-->
    <button type="button" class="bouton" id="btnAdd" href="#ajouter">Ajouter</button>
    <button type="button" class="bouton"" id="btnModif" href="#modifier" disabled>Modifier</button>
    <button type="button" class="bouton" id="btnSupp" href="#supprimer" disabled>Supprimer</button>
  </div> <!--fin boutons-->

   <?php include('footer.html') ?>
   
</body>

</html>