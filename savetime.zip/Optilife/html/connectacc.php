<?php
	if(!isset($_SESSION)){
?>	<input class="bouton" type=button id="btn" value="Se connecter" onclick="document.location.href=''"/> <!--page de connexion de Hugo-->
<?php	
	}
?>