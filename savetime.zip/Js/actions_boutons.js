function ouvrir_popup(id){
    var popup=document.getElementById(id);
    popup.style.backgroundColor="rgba(0, 0, 0, 0.5)";
    popup.style.visibility="visible";
}

function fermer_popup(id){
    var popup = document.getElementById(id);
    popup.style.visibility="hidden";
}

////Script bouton Optimize
//var bouton_optimize=document.getElementById('bouton_optimize_ss_method');
//var bouton_optimize_method=document.getElementById('bouton_optimize_method');
//var div_optimize=document.getElementById('bouton_optimize');
//
//document.getElementById('bouton_optimize_ss_method').onclick=function()
//    {
//        bouton_optimize_method.
//    };
